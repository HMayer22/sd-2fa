export type InitOpts = { endpoint: string };
export type LoginInput = { email: string; password: string; context?: any };

export class NextShop2FAWeb {
  endpoint: string;
  constructor(opts: InitOpts){ this.endpoint = opts.endpoint.replace(/\/$/,''); }
  autoCollect(){
    const payload = { source:'web', type:'page_load', ua: navigator.userAgent, tz: Intl.DateTimeFormat().resolvedOptions().timeZone, url: location.href };
    // Opcional: enviar para seu backend de logs
    console.debug('[sdk-web] autoCollect', payload);
  }
  async register(email: string, password: string){
    const r = await fetch(this.endpoint + '/auth/register', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password }) });
    return await r.json();
  }
  async login(input: LoginInput){
    const r = await fetch(this.endpoint + '/auth/login', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(input) });
    return await r.json();
  }
  async verify2FA(preAuthToken: string, code: string){
    const r = await fetch(this.endpoint + '/auth/verify-2fa', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ preAuthToken, token: code }) });
    return await r.json();
  }
}
export function initSDK(opts: InitOpts){ return new NextShop2FAWeb(opts); }
