import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { Pool } from 'pg';
import { createClient } from 'redis';
import { z } from 'zod';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import speakeasy from 'speakeasy';
import qrcode from 'qrcode';
import { RiskEngine } from '@nextshop2fa/core';
import { v4 as uuidv4 } from 'uuid';

const app = express();
app.use(helmet());
app.use(express.json({ limit: '1mb' }));

const origins = (process.env.CORS_ORIGINS || '*').split(',').map(s=>s.trim());
app.use(cors({ origin: origins.includes('*') ? true : origins, credentials: true }));

app.use(rateLimit({ windowMs: 60_000, max: 120 }));

const port = Number(process.env.PORT || 4003);
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const redis = createClient({ url: process.env.REDIS_URL });
redis.connect().catch(()=>{});

async function initDb(){
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      totp_secret_base32 TEXT NOT NULL,
      twofa_enabled BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS auth_events(
      id SERIAL PRIMARY KEY,
      ts TIMESTAMP DEFAULT NOW(),
      email TEXT,
      type TEXT,
      data JSONB
    );
  `);
}
initDb().catch(console.error);

const risk = new RiskEngine();

const RegisterSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

app.post('/auth/register', async (req, res)=>{
  const parsed = RegisterSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { email, password } = parsed.data;
  const existing = await pool.query('SELECT id FROM users WHERE email=$1', [email]);
  if (existing.rowCount) return res.status(409).json({ error: 'user_exists' });
  const password_hash = await bcrypt.hash(password, 10);
  const secret = speakeasy.generateSecret({ name: `NextShop2FA (${email})` });
  await pool.query('INSERT INTO users(email,password_hash,totp_secret_base32) VALUES ($1,$2,$3)', [email, password_hash, secret.base32]);
  const otpauth = secret.otpauth_url || speakeasy.otpauthURL({ secret: secret.base32, label: `NextShop2FA (${email})`, issuer: 'NextShop2FA' });
  const qrcodeDataURL = await qrcode.toDataURL(otpauth);
  res.json({ email, otpauth, qrcodeDataURL, secretBase32: secret.base32 });
});

const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  context: z.object({
    sessionId: z.string(),
    failedAttempts: z.number().optional(),
    recentIpCount: z.number().optional(),
    deviceUnrecognized: z.boolean().optional(),
    geoMismatch: z.boolean().optional(),
    userAgent: z.string().optional(),
    orderAmount: z.number().optional(),
    averageOrder: z.number().optional()
  }).partial().default({ sessionId: '' })
});

app.post('/auth/login', async (req, res)=>{
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const { email, password, context } = parsed.data;
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  if (!rows.length) return res.status(404).json({ error: 'user_not_found' });
  const user = rows[0];
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) {
    await pool.query('INSERT INTO auth_events(email,type,data) VALUES ($1,$2,$3)', [email, 'login_failed', { reason: 'bad_password' }]);
    return res.status(401).json({ error: 'invalid_credentials' });
  }

  const evaluation = risk.evaluate({ event: 'login', sessionId: context.sessionId || 's', failedAttempts: context.failedAttempts, recentIpCount: context.recentIpCount, deviceUnrecognized: context.deviceUnrecognized, geoMismatch: context.geoMismatch, emailVerified: true, userAgent: context.userAgent });
  if (evaluation.decision === 'block') {
    await pool.query('INSERT INTO auth_events(email,type,data) VALUES ($1,$2,$3)', [email, 'login_block', evaluation]);
    return res.status(403).json(evaluation);
  }

  // Always require TOTP if twofa_enabled
  if (user.twofa_enabled || evaluation.decision === 'challenge') {
    const preAuthToken = jwt.sign({ sub: email, stage: '2fa_pending' }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '5m' });
    await pool.query('INSERT INTO auth_events(email,type,data) VALUES ($1,$2,$3)', [email, '2fa_required', evaluation]);
    return res.status(202).json({ need2FA: true, decision: evaluation.decision, preAuthToken, message: 'Digite o código do seu Authenticator' });
  }

  const token = jwt.sign({ sub: email, stage: 'authenticated' }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '1h' });
  await pool.query('INSERT INTO auth_events(email,type,data) VALUES ($1,$2,$3)', [email, 'login_success', { decision: evaluation.decision }]);
  res.json({ token, decision: evaluation.decision });
});

const VerifySchema = z.object({
  preAuthToken: z.string(),
  token: z.string().min(6).max(8)
});
app.post('/auth/verify-2fa', async (req, res)=>{
  const parsed = VerifySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  try {
    const payload:any = jwt.verify(parsed.data.preAuthToken, process.env.JWT_SECRET || 'dev-secret');
    if (payload.stage !== '2fa_pending') return res.status(400).json({ error: 'bad_stage' });
    const email = payload.sub as string;
    const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
    if (!rows.length) return res.status(404).json({ error: 'user_not_found' });
    const user = rows[0];
    const ok = speakeasy.totp.verify({ secret: user.totp_secret_base32, encoding: 'base32', token: parsed.data.token, window: 1 });
    await pool.query('INSERT INTO auth_events(email,type,data) VALUES ($1,$2,$3)', [email, ok ? '2fa_ok' : '2fa_fail', {} ]);
    if (!ok) return res.status(401).json({ error: 'invalid_2fa' });
    const final = jwt.sign({ sub: email, stage: 'authenticated' }, process.env.JWT_SECRET || 'dev-secret', { expiresIn: '1h' });
    res.json({ token: final, success: true });
  } catch (e){
    return res.status(401).json({ error: 'invalid_preAuth' });
  }
});

// Risk evaluate public endpoint
app.post('/risk/evaluate', (req, res)=>{
  const ctx = req.body?.context || {};
  const event = req.body?.event || 'login';
  const out = risk.evaluate({ event, sessionId: ctx.sessionId || 's', failedAttempts: ctx.failedAttempts, recentIpCount: ctx.recentIpCount, deviceUnrecognized: ctx.deviceUnrecognized, geoMismatch: ctx.geoMismatch, emailVerified: ctx.emailVerified, orderAmount: ctx.orderAmount, averageOrder: ctx.averageOrder });
  res.json(out);
});

app.get('/health', (_req,res)=> res.json({ ok: true }));

export function buildServer(){ return app; }
