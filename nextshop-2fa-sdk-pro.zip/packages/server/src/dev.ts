import { buildServer } from './index';
const app = buildServer();
const port = Number(process.env.PORT || 4003);
app.listen(port, ()=> console.log(`[2FA server] http://localhost:${port}`));
