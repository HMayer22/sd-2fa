import { NextShop2FAWeb, initSDK } from '@nextshop2fa/web';

export class TwoFAService {
  private sdk: NextShop2FAWeb;
  constructor(endpoint: string){ this.sdk = initSDK({ endpoint }); }
  autoCollect(){ this.sdk.autoCollect(); }
  register(email: string, password: string){ return this.sdk.register(email, password); }
  login(email: string, password: string, context?: any){ return this.sdk.login({ email, password, context }); }
  verify2FA(preAuthToken: string, code: string){ return this.sdk.verify2FA(preAuthToken, code); }
}
