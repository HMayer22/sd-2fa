import { EventContext, RiskEngineConfig, RiskResponse } from './types';

const defaultCfg: Required<RiskEngineConfig> = {
  thresholds: { allow: 30, challenge: 60, block: 60 }
};

function clamp100(n:number){ return Math.max(0, Math.min(100, n)); }

export class RiskEngine {
  cfg: Required<RiskEngineConfig>;
  constructor(cfg?: RiskEngineConfig){ this.cfg = { ...defaultCfg, ...cfg }; }

  score(ctx: EventContext): number {
    let s=0;
    if (ctx.failedAttempts) s += Math.min(ctx.failedAttempts*15, 45);
    if (ctx.recentIpCount && ctx.recentIpCount>3) s += 25;
    if (ctx.deviceUnrecognized) s += 10;
    if (ctx.geoMismatch) s += 30;
    if (ctx.emailVerified === false) s += 20;
    if (ctx.orderAmount && ctx.averageOrder && ctx.orderAmount > ctx.averageOrder*3) s += 20;
    return clamp100(s);
  }

  decide(n:number): RiskResponse['decision']{
    if (n < this.cfg.thresholds.allow) return 'allow';
    if (n < this.cfg.thresholds.challenge) return 'challenge';
    return 'block';
  }

  evaluate(ctx: EventContext): RiskResponse {
    const score = this.score(ctx);
    const decision = this.decide(score);
    return {
      score,
      decision,
      requiredChallenges: decision === 'challenge' ? ['totp'] : undefined,
      message: decision === 'block' ? 'High risk' : undefined
    };
  }
}
