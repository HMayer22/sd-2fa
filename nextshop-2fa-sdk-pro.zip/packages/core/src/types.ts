export type RiskDecision = 'allow' | 'challenge' | 'block';

export interface EventContext {
  sessionId: string;
  userId?: string;
  ip?: string;
  userAgent?: string;
  deviceId?: string;
  geoMismatch?: boolean;
  failedAttempts?: number;
  recentIpCount?: number;
  deviceUnrecognized?: boolean;
  emailVerified?: boolean;
  orderAmount?: number;
  averageOrder?: number;
  event: 'login'|'checkout'|'add_card';
}

export interface RiskResponse {
  score: number;
  decision: RiskDecision;
  requiredChallenges?: Array<'totp'|'email'>;
  message?: string;
}

export interface RiskEngineConfig {
  thresholds?: { allow: number; challenge: number; block: number };
}
