
# MANUAL COMPLETO — NextShop 2FA SDK Pro

> Leia com calma. Este arquivo explica **literalmente tudo**: o que é TOTP, como instalar, como rodar, como testar, como integrar no **Playground** e em **qualquer app**.

---

## 1) O que é este SDK

- Um **SDK de autenticação forte com 2FA (TOTP)** + **motor de risco**.
- Ele é composto por 4 pacotes:
  - `@nextshop2fa/core`: tipos e RiskEngine.
  - `@nextshop2fa/server`: API Express (Node) com **TOTP** (Google Authenticator e similares), JWT, Postgres, Redis, Helmet e Rate Limit.
  - `@nextshop2fa/web`: SDK front-end (browser) para registrar, logar e verificar 2FA.
  - `@nextshop2fa/angular`: wrapper simples para apps Angular.

Você pode usar **só o servidor** com seu próprio front, ou usar o **SDK web** para simplificar.

---

## 2) O que é TOTP (Authenticator)

- TOTP = **Time-based One-Time Password**: código de 6 dígitos que muda a cada 30s.
- Aplicativos como **Google Authenticator**, **Authy**, **1Password**, **Microsoft Authenticator** implementam TOTP.
- O servidor gera um **secret** para o usuário e fornece um **QRCode**. O usuário escaneia esse QR no app Authenticator.
- No login, além da senha, o usuário informa o **código TOTP**; o servidor verifica o código com o secret armazenado.

---

## 3) Requisitos

- Node.js 18+
- Yarn
- Docker (opcional, mas recomendado) para Postgres e Redis

---

## 4) Instalação e Primeiros Passos

### 4.1) Instalar dependências
```bash
yarn
```

### 4.2) Subir banco e redis (opcional)
```bash
docker compose -f docker/docker-compose.yml up -d
# Postgres em localhost:5433 (DB: nextshop2fa, user: postgres, pass: postgres)
# Redis em localhost:6380
```

### 4.3) Configurar variáveis
Copie `.env.example` para `.env` dentro de `packages/server` e ajuste se necessário.

### 4.4) Subir o servidor 2FA
```bash
yarn dev:server
# Server em http://localhost:4003/health
```

---

## 5) Fluxos e Endpoints (com exemplos)

### 5.1) Registro — gerar secret e QRCode
- **Endpoint**: `POST /auth/register`
- **Body**: `{ "email": "alice@example.com", "password": "SenhaForte123" }`
- **Resposta**: `{ qrcodeDataURL, secretBase32, otpauth }`

**Exemplo curl**:
```bash
curl -X POST http://localhost:4003/auth/register   -H "Content-Type: application/json"   -d '{"email":"alice@example.com","password":"SenhaForte123"}' > register.json
```

**O que fazer**: abra o `qrcodeDataURL` em um viewer ou cole em um HTML `<img src="...">` e **escaneie** com seu app Authenticator.

### 5.2) Login (senha) → requer **2FA**
- **Endpoint**: `POST /auth/login`
- **Body**: 
```json
{
  "email":"alice@example.com",
  "password":"SenhaForte123",
  "context": { "sessionId": "sess-1" }
}
```
- **Resposta esperada**: `202 Accepted` com `{ need2FA: true, preAuthToken }`

**Exemplo curl**:
```bash
curl -X POST http://localhost:4003/auth/login   -H "Content-Type: application/json"   -d '{"email":"alice@example.com","password":"SenhaForte123","context":{"sessionId":"sess-1"}}'   > login.json
```

### 5.3) Verificar 2FA (TOTP)
- **Endpoint**: `POST /auth/verify-2fa`
- **Body**: `{ "preAuthToken": "<do passo anterior>", "token": "<codigo-6-digitos>" }`
- **Resposta**: `200 OK` com `{ token }` (JWT final de sessão)

**Exemplo curl** (troque `CODE` pelo código do seu Authenticator):
```bash
PRE=$(jq -r '.preAuthToken' login.json)
curl -X POST http://localhost:4003/auth/verify-2fa   -H "Content-Type: application/json"   -d '{"preAuthToken":"'"$PRE"'","token":"CODE"}'
```

### 5.4) Avaliação de Risco (opcional)
- **Endpoint**: `POST /risk/evaluate`
- **Body**: `{ "event":"login", "context": { "sessionId":"s", "failedAttempts":2 } }`
- **Resposta**: `{ score, decision }`

---

## 6) SDK Web (como usar no seu front)

```js
import { initSDK } from '@nextshop2fa/web';

const sdk = initSDK({ endpoint: 'http://localhost:4003' });
sdk.autoCollect();

// 1) Registro (uma vez)
const reg = await sdk.register('alice@example.com', 'SenhaForte123');
document.querySelector('#qr').src = reg.qrcodeDataURL;

// 2) Login (senha)
const r = await sdk.login({ email: 'alice@example.com', password: 'SenhaForte123', context: { sessionId: 's-1' } });
if (r.need2FA) {
  const code = prompt('Digite o código do Authenticator');
  const ok = await sdk.verify2FA(r.preAuthToken, code);
  console.log('Autenticado!', ok);
}
```

---

## 7) Integração com o **Playground** que você já tem

Você já possui o `sdk-playground.zip`. Existem 2 formas de integrar:

### Opção A — Usar o **adapter** como middleware
1. Suba o servidor 2FA (`yarn dev:server` → porta **4003**).
2. No repositório do **playground**, crie a pasta `sdks/2fa-adapter/server` e copie o arquivo:
   - `integration/playground-adapter/server/index.ts` **deste SDK** → para `sdk-playground/sdks/2fa-adapter/server/index.ts`.
3. Instale a dependência `node-fetch` no **backend do playground** (se necessário).
4. Exporte a variável de ambiente no backend do playground: `TWOFA_API=http://localhost:4003`.
5. Rode o backend do playground (`yarn dev:api`) e o front (`yarn dev:web`).
6. Faça login na loja. O adapter vai responder **challenge** e incluir `preAuthToken`. Use o terminal para verificar `/auth/verify-2fa` no servidor 2FA.

### Opção B — Consumir diretamente as rotas do 2FA
- Ajuste seu front do playground para chamar **direto** `http://localhost:4003/auth/login` e depois `.../verify-2fa`.
- Simples e sem middleware, porém você usa 2 backends.

> Dica: comece pela **Opção A** para aproveitar o fluxo existente do playground.

---

## 8) Segurança e Boas Práticas (importante)

- **Hashed passwords** com `bcrypt` (nunca armazenar senha em texto).  
- **JWT** com `JWT_SECRET` forte e **expiração** curta.  
- **TOTP** com `window=1` (tolerância de 30s) — pode ajustar.  
- **Helmet** e **rate limit** habilitados.  
- **TLS/HTTPS** obrigatório em produção.  
- **CSP** no seu front (Content Security Policy).  
- **Postgres** com backups, acesso restrito e usuário dedicado.  
- **Rotacionar segredo TOTP** em caso de suspeita.  
- **Revogar sessões** em reset de senha.

---

## 9) Estrutura do Código (mapa rápido)

```
packages/core/src
  ├─ types.ts
  └─ riskEngine.ts

packages/server/src
  ├─ index.ts     # rotas /auth/register, /auth/login, /auth/verify-2fa, /risk/evaluate
  └─ dev.ts       # sobe o servidor (porta 4003)

packages/web/src
  └─ index.ts     # initSDK, register, login, verify2FA

packages/angular/src
  └─ index.ts     # TwoFAService (wrapper)
```

---

## 10) Testes (sugestão de roteiro manual)

1. **Registro** do usuário → ver QRCode → escanear no Authenticator.  
2. **Login** com senha → receber `need2FA` e `preAuthToken`.  
3. **Verificar 2FA** com o **código atual** do Authenticator → receber **JWT**.  
4. **Código errado** → deve falhar (401).  
5. Esperar 1 minuto e tentar com o código antigo → deve falhar.  
6. Rodar `/risk/evaluate` com `failedAttempts=3` → ver decisão **challenge** ou **block**.

---

## 11) Erros comuns e soluções

- **`user_exists`**: tente outro e-mail.  
- **`user_not_found`**: registre antes.  
- **`invalid_credentials`**: senha errada.  
- **`invalid_preAuth`**: `preAuthToken` expirado (refaça o login).  
- **`invalid_2fa`**: código incorreto ou fora da janela.  
- **Banco indisponível**: verifique Docker e `DATABASE_URL`.  
- **CORS**: ajuste `CORS_ORIGINS` no `.env`.

---

## 12) Produção (checklist rápido)

- Use **HTTPS** (TLS) e **domínio próprio**.  
- Configure **CORS** estrito (origens específicas).  
- Segredo JWT forte em **variável de ambiente**.  
- Banco **gerenciado** (RDS/GCP SQL) e **Redis** gerenciado.  
- Observabilidade (logs + métricas).  
- Backups e migrações versionadas.

---

## 13) Licença

MIT (exemplo educacional).
