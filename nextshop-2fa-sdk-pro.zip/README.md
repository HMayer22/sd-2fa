# NextShop 2FA SDK Pro
Veja docs/MANUAL_COMPLETO.md para instruções detalhadas.
