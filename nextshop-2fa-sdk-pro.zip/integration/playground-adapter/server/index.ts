// Middleware para integrar o servidor 2FA ao sdk-playground backend.
// Usa a rota /api/auth/login do playground e delega autenticação ao servidor 2FA.
import fetch from 'node-fetch';

const BASE = process.env.TWOFA_API || 'http://localhost:4003';

export async function middleware(req:any, res:any, next:any){
  if (req.path.includes('/api/auth/login')){
    try{
      const body = req.body || {};
      const r = await fetch(BASE + '/auth/login', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ email: body.email, password: body.password, context: body.context || { sessionId: 's' } })
      });
      const data = await r.json();
      if (r.status === 202 && data.need2FA){
        // sinaliza challenge para o playground
        req.sdkDecision = { decision: 'challenge', source: '2fa', need2FA: true, preAuthToken: data.preAuthToken, message: 'Informe o código TOTP do seu Authenticator e chame /auth/verify-2fa no servidor 2FA.' };
      } else if (!r.ok){
        req.sdkDecision = { decision: 'block', source: '2fa', message: data?.error || 'blocked' };
      } else {
        // sucesso direto (caso sem 2FA) — apenas segue
      }
    } catch(e){
      req.sdkDecision = { decision: 'block', source: '2fa', message: '2FA server unreachable' };
    }
  }
  next();
}
