import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import helmet from 'helmet';
import cors from 'cors';
import dotenv from 'dotenv';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import speakeasy from 'speakeasy';
import QRCode from 'qrcode';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Config
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';
const FACE_THRESHOLD = parseFloat(process.env.FACE_THRESHOLD || '0.6');

// DB setup
const db = new Database(path.join(__dirname, 'db.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT,
  dob TEXT,
  password_hash TEXT NOT NULL,
  totp_secret TEXT,
  face_descriptor TEXT
);
`);

// Express
const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({limit: '2mb'}));

// serve frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// helpers
function validatePasswordPolicy(pw) {
  // min 8, at least 1 uppercase, and at least one symbol among . , @ # $ %
  const minLen = pw && pw.length >= 8;
  const hasUpper = /[A-Z]/.test(pw);
  const hasSymbol = /[\.,@#$%]/.test(pw);
  return minLen && hasUpper && hasSymbol;
}

function signToken(user) {
  const payload = { sub: user.id, email: user.email, name: user.name };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });
}

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing_token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    return next();
  } catch (e) {
    return res.status(401).json({ error: 'invalid_token' });
  }
}

// routes
app.post('/api/register', (req, res) => {
  const { name, email, phone, dob, password } = req.body || {};
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'missing_fields' });
  }
  if (!validatePasswordPolicy(password)) {
    return res.status(400).json({ error: 'weak_password', policy: 'Min 8, 1 maiúscula, 1 símbolo (.,@#$%)' });
  }
  const hash = bcrypt.hashSync(password, 10);
  try {
    const stmt = db.prepare(`INSERT INTO users (name, email, phone, dob, password_hash) VALUES (?,?,?,?,?)`);
    const info = stmt.run(name, email, phone || '', dob || '', hash);
    return res.json({ ok: true, id: info.lastInsertRowid });
  } catch (e) {
    if (e.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ error: 'email_in_use' });
    }
    console.error(e);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'missing_fields' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(401).json({ error: 'invalid_credentials' });
  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid_credentials' });

  const hasTotp = !!user.totp_secret;
  const hasFace = !!user.face_descriptor;
  if (!hasTotp && !hasFace) {
    // no additional challenge -> issue token
    const token = signToken(user);
    return res.json({ ok: true, token });
  }
  // return challenge options; client will choose TOTP or FACE
  return res.json({
    ok: true,
    challenge_required: true,
    methods: { totp: hasTotp, face: hasFace },
    email: user.email
  });
});

// 2FA setup
app.post('/api/2fa/setup', async (req, res) => {
  const { email } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(404).json({ error: 'user_not_found' });

  const secret = speakeasy.generateSecret({ length: 20, name: `AuthApp (${email})` });
  const otpauth = secret.otpauth_url;
  const qrDataUrl = await QRCode.toDataURL(otpauth);

  // temporarily store secret (we will only persist after verify)
  // For simplicity, we include the secret in response; in production, cache server-side.
  return res.json({ otpauth_url: otpauth, base32: secret.base32, qr: qrDataUrl });
});

app.post('/api/2fa/verify', (req, res) => {
  const { email, token, base32 } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(404).json({ error: 'user_not_found' });
  if (!base32 || !token) return res.status(400).json({ error: 'missing_fields' });

  const verified = speakeasy.totp.verify({ secret: base32, encoding: 'base32', token, window: 1 });
  if (!verified) return res.status(400).json({ error: 'invalid_token' });

  db.prepare('UPDATE users SET totp_secret = ? WHERE id = ?').run(base32, user.id);
  return res.json({ ok: true });
});

app.post('/api/2fa/authenticate', (req, res) => {
  const { email, token } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !user.totp_secret) return res.status(400).json({ error: 'no_2fa_setup' });
  const verified = speakeasy.totp.verify({ secret: user.totp_secret, encoding: 'base32', token, window: 1 });
  if (!verified) return res.status(401).json({ error: 'invalid_token' });
  const jwtToken = signToken(user);
  return res.json({ ok: true, token: jwtToken });
});

// Face register
app.post('/api/face/register', (req, res) => {
  const { email, descriptor } = req.body || {};
  if (!email || !Array.isArray(descriptor)) return res.status(400).json({ error: 'bad_request' });
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(404).json({ error: 'user_not_found' });
  // store as JSON string
  const json = JSON.stringify(descriptor);
  db.prepare('UPDATE users SET face_descriptor = ? WHERE id = ?').run(json, user.id);
  return res.json({ ok: true });
});

function euclidean(a, b) {
  if (!a || !b || a.length !== b.length) return Number.POSITIVE_INFINITY;
  let s = 0;
  for (let i = 0; i < a.length; i++) {
    const d = (a[i] - b[i]);
    s += d * d;
  }
  return Math.sqrt(s);
}

app.post('/api/face/authenticate', (req, res) => {
  const { email, descriptor } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !user.face_descriptor) return res.status(400).json({ error: 'no_face_setup' });
  const stored = JSON.parse(user.face_descriptor);
  const dist = euclidean(descriptor, stored);
  if (dist <= FACE_THRESHOLD) {
    const token = signToken(user);
    return res.json({ ok: true, token, distance: dist });
  }
  return res.status(401).json({ error: 'face_not_match', distance: dist });
});

app.get('/api/profile', authMiddleware, (req, res) => {
  const user = db.prepare('SELECT id, name, email, phone, dob FROM users WHERE id = ?').get(req.user.sub);
  return res.json({ ok: true, user });
});

// fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
