Coloque aqui os modelos do face-api.js para rodar offline (sem internet). Estrutura sugerida:

frontend/
  models/
    face_recognition_model-weights_manifest.json
    face_recognition_model-shard1
    face_landmark_68_model-weights_manifest.json
    face_landmark_68_model-shard1
    tiny_face_detector_model-weights_manifest.json
    tiny_face_detector_model-shard1

No código atual, para simplificar, usamos um descritor MOCK gerado dos pixels do vídeo.
Para reconhecimento real, substitua o computeDescriptorMock por chamadas ao face-api.js e garanta
os arquivos de modelo acima nesta pasta.
