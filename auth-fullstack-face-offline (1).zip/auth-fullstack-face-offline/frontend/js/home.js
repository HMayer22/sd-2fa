function $(sel){ return document.querySelector(sel); }

async function getProfile(){
  const token = localStorage.getItem('token');
  const r = await fetch('/api/profile', { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) {
    $('#profile').textContent = 'Token inválido ou expirado.';
    return;
  }
  const j = await r.json();
  $('#profile').textContent = JSON.stringify(j.user, null, 2);
  $('#welcome').textContent = `Bem-vindo, ${j.user.name}!`;
}

document.addEventListener('DOMContentLoaded', ()=>{
  $('#btn-profile').addEventListener('click', getProfile);
  $('#btn-logout').addEventListener('click', ()=>{
    localStorage.removeItem('token');
    window.location.href = 'index.html';
  });
  // auto load
  getProfile();
});
