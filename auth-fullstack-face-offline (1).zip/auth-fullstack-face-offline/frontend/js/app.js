const API = {
  login: (email, password) => fetch('/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})}).then(r=>r.json()),
  totpAuth: (email, token) => fetch('/api/2fa/authenticate', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email, token})}).then(r=>r.json()),
  faceAuth: (email, descriptor) => fetch('/api/face/authenticate', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email, descriptor})}).then(r=>r.json()),
};

let currentEmail = null;
let modelsReady = false;

// Basic face descriptor using canvas pixels as a fallback mock if models missing (not secure).
async function computeDescriptorMock(video) {
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  // simple average chunks to 128-dim vector
  const vec = new Array(128).fill(0);
  for (let i=0;i<data.length;i+=4){
    const v = (data[i]+data[i+1]+data[i+2])/3/255;
    vec[(i/4)%128] += v;
  }
  const n = data.length/4/128;
  for (let i=0;i<128;i++) vec[i] /= n;
  return vec;
}

function $(sel){ return document.querySelector(sel); }
function openModal(){ $('#challenge-modal').classList.add('open'); }
function closeModal(){ $('#challenge-modal').classList.remove('open'); }

function switchTab(tab){
  const totp = $('#pane-totp'); const face = $('#pane-face');
  const btT = $('#tab-totp'); const btF = $('#tab-face');
  if (tab==='totp'){ totp.style.display='block'; face.style.display='none'; btT.classList.add('active'); btF.classList.remove('active'); }
  else { face.style.display='block'; totp.style.display='none'; btF.classList.add('active'); btT.classList.remove('active'); }
}

async function initFace(){
  $('#face-note').textContent = 'Inicializando câmera...';
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    const video = $('#video');
    video.srcObject = stream;
    video.onloadedmetadata = () => video.play();
    modelsReady = true; // models local: em produção, troque por checagem real
    $('#face-note').textContent = 'Pronto para captura.';
    $('#btn-face-capture').disabled = false;
  } catch (e) {
    $('#face-note').textContent = 'Câmera não disponível: ' + e.message;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('login-form');
  const msg = document.getElementById('message');

  $('#tab-totp').addEventListener('click', ()=>switchTab('totp'));
  $('#tab-face').addEventListener('click', ()=>switchTab('face'));
  $('#btn-close').addEventListener('click', closeModal);
  $('#btn-close-2').addEventListener('click', closeModal);

  $('#mfa-button').addEventListener('click', ()=>{ openModal(); switchTab('totp'); });
  $('#bio-button').addEventListener('click', async ()=>{ openModal(); switchTab('face'); await initFace(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    msg.textContent = '';
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const resp = await API.login(email, password);
    if (!resp.ok) {
      msg.style.color = '#ff8888';
      msg.textContent = resp.error || 'Falha no login';
      return;
    }
    if (resp.token) {
      localStorage.setItem('token', resp.token);
      window.location.href = 'home.html';
      return;
    }
    // Challenge required
    currentEmail = resp.email;
    openModal();
  });

  document.getElementById('btn-totp-confirm').addEventListener('click', async () => {
    const code = document.getElementById('totp-code').value.trim();
    if (!currentEmail || !code) return;
    const r = await API.totpAuth(currentEmail, code);
    if (r.ok && r.token) {
      localStorage.setItem('token', r.token);
      window.location.href = 'home.html';
    } else {
      alert('Código inválido.');
    }
  });

  document.getElementById('btn-face-capture').addEventListener('click', async () => {
    if (!currentEmail) return;
    const video = document.getElementById('video');
    const desc = await computeDescriptorMock(video); // substitua pela face-api real quando modelos estiverem presentes
    const r = await API.faceAuth(currentEmail, desc);
    if (r.ok && r.token) {
      localStorage.setItem('token', r.token);
      window.location.href = 'home.html';
    } else {
      alert('Face não reconhecida.' + (r.distance ? ` Distância: ${r.distance.toFixed(3)}` : ''));
    }
  });
});
