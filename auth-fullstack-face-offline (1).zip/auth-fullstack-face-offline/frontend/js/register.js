const API = {
  register: (payload) => fetch('/api/register', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)}).then(r=>r.json()),
  setup2fa: (email) => fetch('/api/2fa/setup', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email })}).then(r=>r.json()),
  verify2fa: (email, token, base32) => fetch('/api/2fa/verify', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, token, base32 })}).then(r=>r.json()),
  faceRegister: (email, descriptor) => fetch('/api/face/register', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, descriptor })}).then(r=>r.json()),
};

let currentEmail = null;

function $(sel){ return document.querySelector(sel); }

function validatePassword(pw){
  const min = pw.length >= 8;
  const upper = /[A-Z]/.test(pw);
  const sym = /[\.,@#$%]/.test(pw);
  return min && upper && sym;
}

async function initFace(){
  $('#face-note').textContent = 'Inicializando câmera...';
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    const video = $('#video');
    video.srcObject = stream;
    video.onloadedmetadata = () => video.play();
    $('#face-note').textContent = 'Aponte o rosto para a câmera e clique em Capturar & Salvar.';
    $('#btn-face-capture').disabled = false;
  } catch (e) {
    $('#face-note').textContent = 'Câmera não disponível: ' + e.message;
  }
}

// Same mock as login (replace with real face-api when models available)
async function computeDescriptorMock(video) {
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  const data = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  const vec = new Array(128).fill(0);
  for (let i=0;i<data.length;i+=4){
    const v = (data[i]+data[i+1]+data[i+2])/3/255;
    vec[(i/4)%128] += v;
  }
  const n = data.length/4/128;
  for (let i=0;i<128;i++) vec[i] /= n;
  return vec;
}

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('register-form');
  const msg = document.getElementById('message');
  initFace();

  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    msg.textContent = '';
    const payload = {
      name: $('#name').value.trim(),
      dob: $('#dob').value,
      email: $('#email').value.trim(),
      phone: $('#phone').value.trim(),
      password: $('#password').value
    };
    if (!validatePassword(payload.password)){
      msg.style.color = '#ff8888';
      msg.textContent = 'Senha fraca: Min 8, 1 maiúscula, 1 símbolo (.,@#$%)';
      return;
    }
    const r = await API.register(payload);
    if (r.ok){
      msg.style.color = '#88ff88';
      msg.textContent = 'Usuário registrado.';
      currentEmail = payload.email;
      $('#btn-setup-2fa').disabled = false;
    } else {
      msg.style.color = '#ff8888';
      msg.textContent = r.error || 'Erro no registro';
    }
  });

  $('#btn-setup-2fa').addEventListener('click', async ()=>{
    if (!currentEmail) { alert('Registre primeiro.'); return; }
    const data = await API.setup2fa(currentEmail);
    if (data.qr){
      $('#qr-box').innerHTML = `<img src="${data.qr}" alt="QR 2FA" style="width:220px;height:220px;border:1px solid #2543a1;border-radius:8px;padding:6px;background:#001033;">`;
      $('#qr-box').dataset.base32 = data.base32;
    }
  });

  $('#btn-verify-2fa').addEventListener('click', async ()=>{
    const code = $('#totp-verify').value.trim();
    const base32 = $('#qr-box').dataset.base32;
    if (!currentEmail || !code || !base32) return;
    const r = await API.verify2fa(currentEmail, code, base32);
    if (r.ok){
      alert('2FA ativado!');
    } else {
      alert('Código inválido.');
    }
  });

  $('#btn-face-capture').addEventListener('click', async ()=>{
    if (!currentEmail) { alert('Registre primeiro.'); return; }
    const video = $('#video');
    const desc = await computeDescriptorMock(video);
    const r = await API.faceRegister(currentEmail, desc);
    if (r.ok){
      alert('Face cadastrada!');
    } else {
      alert('Falha ao cadastrar face.');
    }
  });
});
