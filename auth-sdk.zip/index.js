import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { loadDB, saveDB } from "./storage.js";
import { generate2FA, generateQRCode, verify2FA } from "./totp.js";

const JWT_SECRET = "sdk_secret_change_me";

// Registro usuário
export function registerUser({ name, email, password }) {
  const db = loadDB();
  if (db.users.find(u => u.email === email)) {
    throw new Error("Usuário já existe");
  }

  const hash = bcrypt.hashSync(password, 10);
  const newUser = { id: Date.now(), name, email, passwordHash: hash };
  db.users.push(newUser);
  saveDB(db);

  return newUser;
}

// Login
export function loginUser({ email, password }) {
  const db = loadDB();
  const user = db.users.find(u => u.email === email);
  if (!user || !bcrypt.compareSync(password, user.passwordHash)) {
    throw new Error("Credenciais inválidas");
  }
  const token = jwt.sign({ sub: user.id, email }, JWT_SECRET, { expiresIn: "2h" });
  return { user, token };
}

// Gerenciar 2FA
export function setup2FA(email) {
  const { base32, otpauth_url } = generate2FA(email);
  return { base32, otpauth_url };
}

export { generateQRCode, verify2FA };
